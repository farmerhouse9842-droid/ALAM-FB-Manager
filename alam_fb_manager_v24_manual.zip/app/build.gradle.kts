plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.alam.fbmanager"
    compileSdk = 35
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    defaultConfig {
        applicationId = "com.alam.fbmanager"
        minSdk = 28
        targetSdk = 35
        versionCode = 6
        versionName = "2.4"
    }
}

kotlin {
    jvmToolchain(17)
}
