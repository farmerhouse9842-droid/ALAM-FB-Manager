ALAM FB Manager v4.7 - Compact Window Page

Changes from v4.6:
- Shortened the Grid page header and removed long helper paragraphs above the windows.
- Reduced the height of the comment draft field and its Save, Copy, Drafts and Go to Post controls.
- Retained existing Facebook WebView behavior, separate profiles, comments navigation, window controls and sections.

Important: Facebook's "Open app" button is rendered by Facebook inside its own website. This update does not remove or resize Facebook's page elements, which cannot be reliably controlled by the Android host application. The surrounding app controls now use less screen space.

Not built or device-tested. Upload this ZIP as alam_fb_manager_github_upload.zip for the existing GitHub workflow.
