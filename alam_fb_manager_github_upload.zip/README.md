# ALAM FB Manager v2.0

Android app with a neon dark interface, portrait-based icon, 10/20 selectable account slots, Grid and Switch navigation, and a link input. Each slot opens **manually** in its own WebView process (Android 9+). Grid View is a grid of account shortcuts, **not 20 simultaneous video players**. No auto-play, auto-refresh, or artificial engagement.

## Build
Upload the **contents** of this folder to a GitHub repository. Open Actions > Build Android APK > Run workflow, then download the debug APK artifact. Requires GitHub Actions and Android SDK; the APK has not been compiled or tested here.

Facebook may block login in embedded WebView; this app is not affiliated with Meta. Some phones may kill background processes, and 20 isolated sessions use significant storage/RAM. Do not enter passwords unless you trust the source and the Facebook login page.
