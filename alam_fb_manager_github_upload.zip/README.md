ALAM FB Manager v4.2 (based on v3.9)

- Custom 1–200 slot selection and 20-slot paginated sections.
- Live browsing remains limited to the original 20 accounts; slots 21–200 are reserved placeholders.
- Refresh Grid View redraws the UI without reloading or destroying open WebViews.
- Existing login profiles, navigation, sound, and compact browser code retained.
- No bulk multi-account loading or playback added.

Build not verified on device.
