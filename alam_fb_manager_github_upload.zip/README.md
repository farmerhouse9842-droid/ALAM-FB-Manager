ALAM FB Manager v4.7 - Compact Window Page

Changes from v4.6:
- Shortened the Grid page header and removed long helper paragraphs above the windows.
- Reduced the height of the comment draft field and its Save, Copy, Drafts and Go to Post controls.
- Retained existing Facebook WebView behavior, separate profiles, comments navigation, window controls and sections.

Important: Facebook's "Open app" button is rendered by Facebook inside its own website. This update does not remove or resize Facebook's page elements, which cannot be reliably controlled by the Android host application. The surrounding app controls now use less screen space.

Not built or device-tested. Upload this ZIP as alam_fb_manager_github_upload.zip for the existing GitHub workflow.

## Facebook window actions
Each Facebook window now has LIKE, COMMENT and SHARE buttons. They expand that window and open the supplied link, if available. Interactions must be completed manually using Facebook controls. WebView cookies may be shared between windows.


## Facebook sharing and data-saving limits
- SHARE in each window opens Facebook's web sharing page **inside that window** with the selected Facebook link. Facebook may require login or reject some links; the user must confirm publishing. No Android share chooser or Graph API access token is used.
- Facebook video Data Saver cannot be enabled globally via Android WebView or Meta Graph API. The app does not claim to force a video quality. Autoplay and page mute remain best-effort.
- Multiple WebViews can still use significant RAM and bandwidth.

UI cleanup: Removed explanatory hint text from Comments and Grid screens. Posting remains user-confirmed; Facebook controls depend on the live site.
