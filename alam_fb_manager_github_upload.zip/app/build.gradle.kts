plugins { id("com.android.application") }
android { namespace = "com.alam.fbmanager"; compileSdk = 35
 defaultConfig { applicationId = "com.alam.fbmanager"; minSdk = 28; targetSdk = 35; versionCode = 2; versionName = "2.0" } }
