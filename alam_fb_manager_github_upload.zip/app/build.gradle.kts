plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.alam.fbmanager"
    compileSdk = 35
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    defaultConfig {
        applicationId = "com.alam.fbmanager"
        minSdk = 28
        targetSdk = 35
        versionCode = 4
        versionName = "2.2"
    }
}

kotlin {
    jvmToolchain(17)
}
