plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.alam.fbmanager"
    compileSdk = 35
    defaultConfig {
        applicationId = "com.alam.fbmanager"
        minSdk = 28
        targetSdk = 35
        versionCode = 3
        versionName = "2.1"
    }
}
