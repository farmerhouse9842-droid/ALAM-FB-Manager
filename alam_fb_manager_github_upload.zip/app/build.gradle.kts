plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.alam.fbmanager"
    compileSdk = 35
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    defaultConfig {
        applicationId = "com.alam.fbmanager"
        minSdk = 28
        targetSdk = 35
        versionCode = 20
        versionName = "4.7-compact-layout"
    }
}

kotlin {
    jvmToolchain(17)
}

 dependencies {
    implementation("androidx.webkit:webkit:1.12.1")
}
