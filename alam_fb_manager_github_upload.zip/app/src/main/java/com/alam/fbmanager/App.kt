package com.alam.fbmanager

import android.app.Application
import android.os.Build
import android.webkit.WebView

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        // Each account runs in a distinct process and has isolated WebView storage.
        val process = if (Build.VERSION.SDK_INT >= 28) getProcessName() else ""
        val slot = Regex(":slot(\\d+)$").find(process)?.groupValues?.get(1)
        if (slot != null && Build.VERSION.SDK_INT >= 28) WebView.setDataDirectorySuffix("slot$slot")
    }
}
