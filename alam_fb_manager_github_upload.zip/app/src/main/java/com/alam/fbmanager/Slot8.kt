package com.alam.fbmanager
class Slot8 : AccountActivity()
