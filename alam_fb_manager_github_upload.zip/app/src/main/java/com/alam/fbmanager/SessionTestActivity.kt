package com.alam.fbmanager

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

/** Two explicitly launched, isolated login sessions. No automatic playback. */
class SessionTestActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 36, 24, 24)
            setBackgroundColor(Color.rgb(4, 10, 25))
        }
        val title = TextView(this).apply {
            text = "ALAM FB MANAGER\n2 ACCOUNT LOGIN TEST"
            textSize = 22f
            setTextColor(Color.CYAN)
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 130))
        val info = TextView(this).apply {
            text = "Open Account 1 and sign in. Return here, then open Account 2 and sign in with a different account. Open each again to verify separate sessions."
            setTextColor(Color.WHITE)
            textSize = 15f
        }
        root.addView(info)
        for (i in 1..2) {
            val button = Button(this).apply {
                text = "OPEN ACCOUNT $i"
                setOnClickListener {
                    val activityClass = if (i == 1) Slot1::class.java else Slot2::class.java
                    startActivity(Intent(this@SessionTestActivity, activityClass))
                }
            }
            root.addView(button, LinearLayout.LayoutParams(-1, 90))
        }
        val back = Button(this).apply { text = "BACK TO HOME"; setOnClickListener { finish() } }
        root.addView(back)
        setContentView(root)
    }
}
