package com.alam.fbmanager
class Slot17 : AccountActivity()
