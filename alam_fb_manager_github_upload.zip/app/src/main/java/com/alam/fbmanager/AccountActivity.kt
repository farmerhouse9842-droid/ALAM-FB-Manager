package com.alam.fbmanager

import android.app.Activity
import android.os.Bundle
import android.webkit.*
import android.widget.LinearLayout
import android.widget.Button
import android.widget.EditText
import android.text.InputType

open class AccountActivity : Activity() {
    private lateinit var browser: WebView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val url = EditText(this).apply {
            setSingleLine(true); hint = "Paste Facebook Reel URL"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        val open = Button(this).apply { text = "Open Reel" }
        val home = Button(this).apply { text = "Facebook Home" }
        val toolbar = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        toolbar.addView(url); toolbar.addView(open); toolbar.addView(home)
        layout.addView(toolbar)
        browser = WebView(this)
        browser.settings.javaScriptEnabled = true
        browser.settings.domStorageEnabled = true
        browser.settings.mediaPlaybackRequiresUserGesture = true
        browser.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val target = request.url
                return target.scheme != "https" && target.scheme != "http"
            }
        }
        layout.addView(browser, LinearLayout.LayoutParams(-1, 0, 1f))
        open.setOnClickListener {
            val target = url.text.toString().trim()
            val uri = android.net.Uri.parse(target)
            if (uri.scheme == "https" && (uri.host == "facebook.com" || uri.host == "www.facebook.com" || uri.host == "m.facebook.com" || uri.host == "fb.watch")) browser.loadUrl(target)
            else url.error = "Use a valid HTTPS Facebook link"
        }
        home.setOnClickListener { browser.loadUrl("https://m.facebook.com/") }
        setContentView(layout)
        val requested = intent.getStringExtra("video_url")
        if (requested != null && requested.isNotBlank()) { url.setText(requested); browser.loadUrl(requested) } else browser.loadUrl("https://m.facebook.com/")
    }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() { if (browser.canGoBack()) browser.goBack() else super.onBackPressed() }
    override fun onDestroy() { browser.destroy(); super.onDestroy() }
}
