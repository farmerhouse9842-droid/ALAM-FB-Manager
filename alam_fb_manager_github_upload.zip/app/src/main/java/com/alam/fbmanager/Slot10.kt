package com.alam.fbmanager
class Slot10 : AccountActivity()
