package com.alam.fbmanager
class Slot18 : AccountActivity()
