package com.alam.fbmanager
class Slot12 : AccountActivity()
