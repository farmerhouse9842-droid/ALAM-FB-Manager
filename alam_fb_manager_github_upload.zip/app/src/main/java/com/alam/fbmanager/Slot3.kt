package com.alam.fbmanager
class Slot3 : AccountActivity()
