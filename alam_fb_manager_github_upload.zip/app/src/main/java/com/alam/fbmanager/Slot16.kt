package com.alam.fbmanager
class Slot16 : AccountActivity()
