package com.alam.fbmanager
class Slot4 : AccountActivity()
