package com.alam.fbmanager
class Slot1 : AccountActivity()
