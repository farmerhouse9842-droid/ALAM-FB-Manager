package com.alam.fbmanager
class Slot20 : AccountActivity()
