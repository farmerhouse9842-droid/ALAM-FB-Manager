package com.alam.fbmanager
class Slot2 : AccountActivity()
