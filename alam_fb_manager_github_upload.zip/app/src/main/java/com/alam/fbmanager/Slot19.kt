package com.alam.fbmanager
class Slot19 : AccountActivity()
