package com.alam.fbmanager
class Slot14 : AccountActivity()
