package com.alam.fbmanager
class Slot11 : AccountActivity()
