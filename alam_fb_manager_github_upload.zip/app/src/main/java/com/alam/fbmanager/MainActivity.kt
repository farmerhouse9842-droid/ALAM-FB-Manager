package com.alam.fbmanager

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import android.text.TextWatcher
import android.text.Editable
import androidx.webkit.WebViewFeature
import android.webkit.WebView

class MainActivity : Activity() {
 private fun showShareQueue(url:String, total:Int) {
  var step=1
  fun launchShare() {
   val send=Intent(Intent.ACTION_SEND).apply {
    type="text/plain"
    putExtra(Intent.EXTRA_TEXT,url)
   }
   startActivity(Intent.createChooser(send,"Choose Facebook account and confirm share"))
  }
  fun promptNext() {
   // The user must confirm every share in Facebook; Android cannot verify completion.
   android.app.AlertDialog.Builder(this)
    .setTitle("Share account $step of $total")
    .setMessage("Select the intended Facebook account in the sharing app. Confirm the post yourself. Return here to continue. This app cannot detect whether sharing succeeded.")
    .setPositiveButton("OPEN SHARE") { _, _ -> launchShare() }
    .setNeutralButton("NEXT ACCOUNT") { _, _ ->
      if(step < total) { step++; showShareStep(url, step, total) }
      else android.widget.Toast.makeText(this,"Share checklist finished (not verified)",android.widget.Toast.LENGTH_LONG).show()
    }
    .setNegativeButton("CANCEL",null).show()
  }
  promptNext()
 }
 private fun showShareStep(url:String, step:Int, total:Int) {
  android.app.AlertDialog.Builder(this)
   .setTitle("Share account $step of $total")
   .setMessage("Open Facebook sharing, select the correct account, and confirm manually. Return to this app for the next account.")
   .setPositiveButton("OPEN SHARE") { _, _ ->
     val send=Intent(Intent.ACTION_SEND).apply {type="text/plain";putExtra(Intent.EXTRA_TEXT,url)}
     startActivity(Intent.createChooser(send,"Share Facebook link"))
   }
   .setNeutralButton(if(step<total) "NEXT ACCOUNT" else "FINISH") { _, _ ->
     if(step<total) showShareStep(url,step+1,total)
     else android.widget.Toast.makeText(this,"Checklist finished; shares not verified",android.widget.Toast.LENGTH_LONG).show()
   }
   .setNegativeButton("CANCEL",null).show()
 }
 private val bg = Color.rgb(4,10,25)
 private val cyan = Color.rgb(28,211,255)
 private lateinit var link: EditText
 private lateinit var accounts: LinearLayout
 private var count = 10
 private var grid = true
 private var navigating = false
 private fun dp(value:Int):Int = (value * resources.displayMetrics.density + 0.5f).toInt()
 private fun shape(active: Boolean = false): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if(active) Color.rgb(13,91,170) else Color.rgb(13,31,64), Color.rgb(5,15,37))).apply { cornerRadius=dp(18).toFloat(); setStroke(if(active) 4 else 2, if(active) cyan else Color.rgb(25,93,154)) }
 private fun text(s:String, size:Float=16f):TextView = TextView(this).apply { text=s; textSize=size; setTextColor(Color.WHITE); gravity=Gravity.CENTER_VERTICAL; setPadding(dp(10),dp(8),dp(10),dp(8)) }
 private fun button(s:String, active:Boolean=false, click:()->Unit):TextView = text(s,16f).apply { gravity=Gravity.CENTER; typeface=Typeface.DEFAULT_BOLD; background=shape(active); setOnClickListener { click() } }
 private fun add(parent:LinearLayout, view:View, height:Int=-2) { parent.addView(view,LinearLayout.LayoutParams(-1,height).apply { bottomMargin=14 }) }
 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor=bg;window.navigationBarColor=bg
  val scroll=ScrollView(this).apply { setBackgroundColor(bg); isFillViewport=true }
  val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(dp(16),dp(20),dp(16),dp(28)) };scroll.addView(root)
  // Wrap the two-line title instead of clipping it to a fixed 120px height.
  val head=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL; orientation=LinearLayout.HORIZONTAL }
  val name=text("♛  ALAM\nFB MANAGER",25f).apply {
   setTextColor(cyan);typeface=Typeface.DEFAULT_BOLD
   gravity=Gravity.CENTER_VERTICAL; includeFontPadding=true
   setPadding(dp(4),dp(12),dp(4),dp(12))
   setLineSpacing(dp(3).toFloat(),1.0f)
  }
  head.addView(name,LinearLayout.LayoutParams(0,LinearLayout.LayoutParams.WRAP_CONTENT,1f))
  val portrait=ImageView(this).apply { setImageResource(com.alam.fbmanager.R.drawable.portrait); scaleType=ImageView.ScaleType.FIT_CENTER; background=shape(true) }
  head.addView(portrait,LinearLayout.LayoutParams(dp(68),dp(68)).apply {leftMargin=dp(8)})
  add(root,head)
  add(root,text("FB  •  Manage  •  Open",13f).apply {setTextColor(Color.LTGRAY);gravity=Gravity.CENTER;setPadding(dp(8),0,dp(8),dp(10))})
  add(root,text("FACEBOOK PROFILE / PHOTO LINK",17f).apply {setTextColor(cyan);typeface=Typeface.DEFAULT_BOLD})
  link=EditText(this).apply {
   hint="Paste Facebook profile / photo URL"
   setHintTextColor(Color.GRAY);setTextColor(Color.WHITE)
   textSize=15f; setSingleLine(true); isHorizontallyScrolling=true
   gravity=Gravity.CENTER_VERTICAL
   setPadding(dp(16),dp(12),dp(16),dp(12))
   minHeight=dp(56); includeFontPadding=true
   background=shape()
   setSelectAllOnFocus(false)
  }
  add(root,link,dp(58))
  val prefs=getSharedPreferences("alam_preferences",MODE_PRIVATE)
  link.setText(prefs.getString("last_video_url", ""))
  link.addTextChangedListener(object: TextWatcher {
   override fun beforeTextChanged(s:CharSequence?,start:Int,count:Int,after:Int) {}
   override fun onTextChanged(s:CharSequence?,start:Int,before:Int,count:Int) {}
   override fun afterTextChanged(s:Editable?) { prefs.edit().putString("last_video_url",s?.toString().orEmpty()).apply() }
  })
  add(root,text("SELECT ACCOUNT COUNT",16f).apply {setTextColor(cyan)})
  val choices=LinearLayout(this);val ten=button("10 Accounts",true){count=10;render()};val twenty=button("20 Accounts"){count=20;render()};choices.addView(ten,LinearLayout.LayoutParams(0,75,1f).apply {rightMargin=7});choices.addView(twenty,LinearLayout.LayoutParams(0,75,1f));add(root,choices)
  val customCount=SeekBar(this).apply { max=199; progress=count-1 }
  val countLabel=text("Selected slots: $count / 200",14f)
  add(root,countLabel)
  add(root,customCount)
  customCount.setOnSeekBarChangeListener(object:SeekBar.OnSeekBarChangeListener {
   override fun onProgressChanged(seekBar:SeekBar?,progress:Int,fromUser:Boolean){
    if(fromUser){count=progress+1;countLabel.text="Selected slots: $count / 200";render()}
   }
   override fun onStartTrackingTouch(seekBar:SeekBar?){}
   override fun onStopTrackingTouch(seekBar:SeekBar?){}
  })
  add(root,text("SELECT VIEW MODE",16f).apply {setTextColor(cyan)})
  val modes=LinearLayout(this);val g=button("▦  Grid View",true){grid=true;render()};val sw=button("▤  Switch View"){grid=false;render()};modes.addView(g,LinearLayout.LayoutParams(0,75,1f).apply {rightMargin=7});modes.addView(sw,LinearLayout.LayoutParams(0,75,1f));add(root,modes)
  val openAccountsButton = button("OPEN ACCOUNTS  ›",true){
   val target=link.text.toString().trim()
   if (!valid(target)) { link.error="Enter a valid HTTPS Facebook link" }
   else startActivity(Intent(this,GridActivity::class.java).putExtra("video_url",target).putExtra("account_count",count).putExtra("section_index",sectionIndex).putExtra("grid_mode",grid))
  }
  openAccountsButton.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(11, 159, 103), Color.rgb(4, 75, 76))).apply { cornerRadius = 36f; setStroke(3, Color.rgb(86, 240, 170)) }
  add(root,openAccountsButton,76)
  add(root,button("SHARE FACEBOOK LINK • INSIDE APP",true){
   val target=link.text.toString().trim()
   if (!valid(target)) link.error="Enter a valid HTTPS Facebook link"
   else startActivity(Intent(this,GridActivity::class.java).putExtra("video_url",target).putExtra("account_count",count).putExtra("section_index",sectionIndex).putExtra("grid_mode",grid).putExtra("share_mode",true))
  },68)

  add(root,button("SHARE ALL • INSIDE FB WINDOWS",true){
   val target=link.text.toString().trim()
   if (!valid(target)) link.error="Enter a valid HTTPS Facebook link"
   else startActivity(Intent(this,GridActivity::class.java).putExtra("video_url",target).putExtra("account_count",count).putExtra("section_index",sectionIndex).putExtra("grid_mode",grid).putExtra("share_mode",true))
  },68)

  val youtubeButton = button("▶  YOUTUBE WINDOWS  •  RED NEON",true){ startActivity(Intent(this,YouTubeActivity::class.java)) }
  youtubeButton.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(Color.rgb(115, 5, 24), Color.rgb(36, 3, 18))).apply {
   cornerRadius=dp(26).toFloat(); setStroke(dp(2),Color.rgb(255, 42, 66))
  }
  youtubeButton.setTextColor(Color.WHITE)
  add(root,youtubeButton,68)
  add(root,button("COMMENTS  •  SAVED DRAFTS",true){ startActivity(Intent(this,CommentsActivity::class.java)) },68)
  add(root,text("ACCOUNTS  •  Open a session individually",14f).apply {setTextColor(Color.LTGRAY)})
  accounts=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL};add(root,accounts)
  fun update(){ten.background=shape(count==10);twenty.background=shape(count==20);g.background=shape(grid);sw.background=shape(!grid);customCount.progress=count-1;countLabel.text="Selected slots: $count / 200"}
  // Render local sessions; deliberately no automated mass-open or playback.
  renderCallback={update()};render();setContentView(scroll)
 }
 override fun onResume() { super.onResume(); navigating=false }
 private var renderCallback:(()->Unit)?=null
 private var sectionIndex=0
 private fun render(){
  if(!::accounts.isInitialized)return
  renderCallback?.invoke();accounts.removeAllViews()
  val sections=(count+19)/20
  sectionIndex=sectionIndex.coerceIn(0,sections-1)
  val start=sectionIndex*20+1
  val end=minOf(count,start+19)
  val navigation=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
  val prev=button("‹ Previous"){sectionIndex=(sectionIndex-1).coerceAtLeast(0);render()}
  val next=button("Next ›"){sectionIndex=(sectionIndex+1).coerceAtMost(sections-1);render()}
  navigation.addView(prev,LinearLayout.LayoutParams(0,55,1f))
  navigation.addView(text("$start–$end",13f).apply {gravity=Gravity.CENTER},LinearLayout.LayoutParams(0,55,1f))
  navigation.addView(next,LinearLayout.LayoutParams(0,55,1f))
  add(accounts,navigation)
  add(accounts,text("Section ${sectionIndex+1} / $sections • $count slots",13f))
  if(grid){ var row:LinearLayout?=null
   for(i in start..end){if((i-start)%2==0){row=LinearLayout(this);add(accounts,row!!)};row!!.addView(button("◉  Account $i"){openSlot(i)},LinearLayout.LayoutParams(0,65,1f).apply{rightMargin=6})}
  }else{for(i in start..end)add(accounts,button("Account $i       ›"){openSlot(i)},64)}
 }
 private fun openSlot(i:Int){val target=link.text.toString().trim();if(target.isNotEmpty() && !valid(target)){link.error="Enter a valid HTTPS Facebook link";return}
  if(i>20){Toast.makeText(this,"Additional slots are reserved. Live browsing is available for slots 1–20.",Toast.LENGTH_LONG).show();return}
  val cls=Class.forName("com.alam.fbmanager.Slot$i");startActivity(Intent(this,cls).putExtra("video_url",target))
 }
 private fun valid(s:String):Boolean = try {val u=android.net.Uri.parse(s);u.scheme=="https" && (u.host?.lowercase()=="facebook.com" || u.host?.lowercase()?.endsWith(".facebook.com")==true || u.host?.lowercase()=="fb.watch")}catch(e:Exception){false}
}
