package com.alam.fbmanager

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
 private val bg = Color.rgb(4,10,25)
 private val cyan = Color.rgb(28,211,255)
 private lateinit var link: EditText
 private lateinit var accounts: LinearLayout
 private var count = 10
 private var grid = true
 private fun shape(active: Boolean = false): GradientDrawable = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(if(active) Color.rgb(13,91,170) else Color.rgb(13,31,64), Color.rgb(5,15,37))).apply { cornerRadius=36f; setStroke(if(active) 4 else 2, if(active) cyan else Color.rgb(25,93,154)) }
 private fun text(s:String, size:Float=16f):TextView = TextView(this).apply { text=s; textSize=size; setTextColor(Color.WHITE); gravity=Gravity.CENTER_VERTICAL; setPadding(12,12,12,12) }
 private fun button(s:String, active:Boolean=false, click:()->Unit):TextView = text(s,16f).apply { gravity=Gravity.CENTER; typeface=Typeface.DEFAULT_BOLD; background=shape(active); setOnClickListener { click() } }
 private fun add(parent:LinearLayout, view:View, height:Int=-2) { parent.addView(view,LinearLayout.LayoutParams(-1,height).apply { bottomMargin=14 }) }
 override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor=bg;window.navigationBarColor=bg
  val scroll=ScrollView(this).apply { setBackgroundColor(bg); isFillViewport=true }
  val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setPadding(20,26,20,30) };scroll.addView(root)
  val head=LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL }
  val name=text("♛  ALAM\n     FB MANAGER",25f).apply { setTextColor(cyan);typeface=Typeface.DEFAULT_BOLD };head.addView(name,LinearLayout.LayoutParams(0,120,1f))
  val portrait=ImageView(this).apply { setImageResource(com.alam.fbmanager.R.drawable.portrait); scaleType=ImageView.ScaleType.FIT_CENTER; background=shape(true) };head.addView(portrait,LinearLayout.LayoutParams(94,94))
  add(root,head);add(root,text("                  FB  •  Manage  •  Open",13f).apply {setTextColor(Color.LTGRAY)})
  add(root,text("FACEBOOK VIDEO LINK",17f).apply {setTextColor(cyan);typeface=Typeface.DEFAULT_BOLD})
  link=EditText(this).apply { hint="Paste Facebook Reel / Video URL";setHintTextColor(Color.GRAY);setTextColor(Color.WHITE);setSingleLine(true);setPadding(22,18,22,18);background=shape() };add(root,link,68)
  add(root,text("SELECT ACCOUNT COUNT",16f).apply {setTextColor(cyan)})
  val choices=LinearLayout(this);val ten=button("10 Accounts",true){count=10;render()};val twenty=button("20 Accounts"){count=20;render()};choices.addView(ten,LinearLayout.LayoutParams(0,75,1f).apply {rightMargin=7});choices.addView(twenty,LinearLayout.LayoutParams(0,75,1f));add(root,choices)
  add(root,text("SELECT VIEW MODE",16f).apply {setTextColor(cyan)})
  val modes=LinearLayout(this);val g=button("▦  Grid View",true){grid=true;render()};val sw=button("▤  Switch View"){grid=false;render()};modes.addView(g,LinearLayout.LayoutParams(0,75,1f).apply {rightMargin=7});modes.addView(sw,LinearLayout.LayoutParams(0,75,1f));add(root,modes)
  add(root,text("ACCOUNTS  •  Tap to open a separate session",14f).apply {setTextColor(Color.LTGRAY)})
  accounts=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL};add(root,accounts)
  fun update(){ten.background=shape(count==10);twenty.background=shape(count==20);g.background=shape(grid);sw.background=shape(!grid)}
  // Render local sessions; deliberately no automated mass-open or playback.
  renderCallback={update()};render();setContentView(scroll)
 }
 private var renderCallback:(()->Unit)?=null
 private fun render(){if(!::accounts.isInitialized)return;renderCallback?.invoke();accounts.removeAllViews()
  if(grid){ var row:LinearLayout?=null
   for(i in 1..count){if((i-1)%2==0){row=LinearLayout(this);add(accounts,row!!)};row!!.addView(button("◉  Account $i"){openSlot(i)},LinearLayout.LayoutParams(0,65,1f).apply{rightMargin=6})}
  }else{for(i in 1..count)add(accounts,button("Account $i       ›"){openSlot(i)},64)}
 }
 private fun openSlot(i:Int){val target=link.text.toString().trim();if(target.isNotEmpty() && !valid(target)){link.error="Enter a valid HTTPS Facebook link";return}
  val cls=Class.forName("com.alam.fbmanager.Slot$i");startActivity(Intent(this,cls).putExtra("video_url",target))
 }
 private fun valid(s:String):Boolean = try {val u=android.net.Uri.parse(s);u.scheme=="https" && (u.host?.lowercase()=="facebook.com" || u.host?.lowercase()?.endsWith(".facebook.com")==true || u.host?.lowercase()=="fb.watch")}catch(e:Exception){false}
}
