package com.alam.fbmanager

import android.app.Activity
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.*
import org.json.JSONArray

/** Local comment drafts only. Posting is performed manually in the browser. */
class CommentsActivity : Activity() {
    private val drafts = mutableListOf<String>()
    private lateinit var list: LinearLayout
    private val prefs by lazy { getSharedPreferences("comment_drafts", MODE_PRIVATE) }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(4, 10, 25)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 22, 22, 22)
            setBackgroundColor(Color.rgb(4, 10, 25))
        }
        val heading = TextView(this).apply { text = "COMMENTS • SAVED DRAFTS"; textSize = 20f; setTextColor(Color.CYAN) }
        root.addView(heading)
        val editor = EditText(this).apply {
            hint = "Write a comment draft"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            minLines = 3
            gravity = Gravity.TOP
        }
        root.addView(editor)
        val add = Button(this).apply { text = "SAVE COMMENT" }
        root.addView(add)
        root.addView(TextView(this).apply {
            text = "SELECT ACCOUNT WINDOW (1–200)"; textSize = 15f; setTextColor(Color.CYAN)
        })
        val selector = Spinner(this)
        val slots = (1..200).map { "Window $it" }
        selector.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, slots)
        root.addView(selector)
        val go = Button(this).apply { text = "GO TO POST / COMMENTS" }
        root.addView(go)
        root.addView(TextView(this).apply {
            text = "Opens the post in the selected browser window. Tap Facebook's Comment button if needed, then paste and post your draft manually."
            setTextColor(Color.LTGRAY); textSize = 12f
        })
        go.setOnClickListener {
            val url = getSharedPreferences("alam_preferences", MODE_PRIVATE)
                .getString("last_video_url", "").orEmpty().trim()
            val uri = android.net.Uri.parse(url)
            val host = uri.host?.lowercase().orEmpty()
            if (uri.scheme != "https" || !(host == "fb.watch" || host == "facebook.com" || host.endsWith(".facebook.com"))) {
                Toast.makeText(this, "First enter a valid Facebook post link on Home", Toast.LENGTH_LONG).show()
            } else {
                val number = selector.selectedItemPosition + 1
                startActivity(Intent(this, GridActivity::class.java)
                    .putExtra("video_url", url)
                    .putExtra("account_count", 200)
                    .putExtra("section_index", (number - 1) / 20)
                    .putExtra("grid_mode", true)
                    .putExtra("open_selected_comment_window", number))
            }
        }
        val scroll = ScrollView(this)
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(list)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        val saved = prefs.getString("drafts", "[]") ?: "[]"
        try { val array = JSONArray(saved); for (i in 0 until array.length()) drafts.add(array.getString(i)) } catch (_: Exception) {}
        add.setOnClickListener {
            val value = editor.text.toString().trim()
            if (value.isNotEmpty()) { drafts.add(value); editor.text.clear(); save(); render() }
        }
        render()
    }
    private fun save() {
        val array = JSONArray()
        drafts.forEach { array.put(it) }
        prefs.edit().putString("drafts", array.toString()).apply()
    }
    private fun render() {
        list.removeAllViews()
        drafts.toList().forEachIndexed { index, draft ->
            val label = TextView(this).apply { text = draft; textSize = 15f; setTextColor(Color.WHITE); setPadding(8, 14, 8, 8) }
            list.addView(label)
            val actions = LinearLayout(this)
            val copy = Button(this).apply { text = "COPY"; setOnClickListener {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("Comment draft", draft))
                Toast.makeText(this@CommentsActivity, "Copied. Paste and post manually.", Toast.LENGTH_SHORT).show()
            } }
            val edit = Button(this).apply { text = "EDIT"; setOnClickListener {
                val input = EditText(this@CommentsActivity).apply { setText(draft) }
                android.app.AlertDialog.Builder(this@CommentsActivity).setTitle("Edit draft").setView(input)
                    .setPositiveButton("Save") { _, _ -> drafts[index] = input.text.toString(); save(); render() }
                    .setNegativeButton("Cancel", null).show()
            } }
            val delete = Button(this).apply { text = "DELETE"; setOnClickListener { drafts.removeAt(index); save(); render() } }
            actions.addView(copy, LinearLayout.LayoutParams(0, -2, 1f))
            actions.addView(edit, LinearLayout.LayoutParams(0, -2, 1f))
            actions.addView(delete, LinearLayout.LayoutParams(0, -2, 1f))
            list.addView(actions)
        }
    }
}
