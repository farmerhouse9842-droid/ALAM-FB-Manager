package com.alam.fbmanager
class Slot15 : AccountActivity()
