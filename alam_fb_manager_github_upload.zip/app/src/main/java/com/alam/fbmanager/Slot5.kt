package com.alam.fbmanager
class Slot5 : AccountActivity()
