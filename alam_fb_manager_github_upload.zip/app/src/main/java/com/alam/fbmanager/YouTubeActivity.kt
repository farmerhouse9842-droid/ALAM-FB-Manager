package com.alam.fbmanager

import android.app.Activity
import android.graphics.Color
import android.os.Bundle
import android.content.Context
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.widget.*
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature

/** Separate YouTube browser section. Windows open only after an explicit tap. */
class YouTubeActivity : Activity() {
    private val red = Color.rgb(242, 62, 79)
    private val bg = Color.rgb(12, 12, 22)
    private val sessions = mutableMapOf<Int, WebView>()
    private val frames = mutableMapOf<Int, FrameLayout>()
    private var section = 0
    private var expanded: Int? = null
    private lateinit var root: LinearLayout
    private lateinit var grid: LinearLayout
    private lateinit var toggle: Button
    private lateinit var urlInput: EditText
    private val prefs by lazy { getSharedPreferences("alam_youtube_windows", Context.MODE_PRIVATE) }
    private fun dp(v:Int)=(v*resources.displayMetrics.density).toInt()
    private fun btn(label:String, callback:()->Unit)=Button(this).apply { text=label; isAllCaps=false; setTextColor(Color.WHITE); setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(125, 29, 43))); setOnClickListener { callback() } }
    private fun text(label:String)=TextView(this).apply { text=label; textSize=14f; setTextColor(Color.WHITE); setPadding(dp(7),dp(7),dp(7),dp(7)) }
    private fun valid(url:String):Boolean = try { val uri=android.net.Uri.parse(url); val host=uri.host?.lowercase().orEmpty(); uri.scheme=="https" && (host=="youtube.com" || host.endsWith(".youtube.com") || host=="youtu.be") } catch (_:Exception){false}
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState)
        window.statusBarColor=bg; window.navigationBarColor=bg
        root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(dp(8),dp(8),dp(8),dp(8)) }
        setContentView(root)
        val tabs=LinearLayout(this)
        tabs.addView(btn("Facebook") { finish() },LinearLayout.LayoutParams(0,dp(46),1f))
        tabs.addView(btn("YouTube  ●") {},LinearLayout.LayoutParams(0,dp(46),1f))
        root.addView(tabs)
        root.addView(text("▶  YOUTUBE WINDOWS  •  RED NEON").apply { setTextColor(red); textSize=18f })
        urlInput=EditText(this).apply { hint="Paste YouTube video, channel or playlist link"; setHintTextColor(Color.LTGRAY);setTextColor(Color.WHITE);setSingleLine(true);setText(prefs.getString("input_url","https://m.youtube.com/")) }
        root.addView(urlInput,LinearLayout.LayoutParams(-1,dp(54)))
        val nav=LinearLayout(this)
        nav.addView(btn("‹ PREV") { changeSection(-1) },LinearLayout.LayoutParams(0,dp(43),1f))
        val sectionLabel=text("Section 1/10").apply { gravity=Gravity.CENTER }
        nav.addView(sectionLabel,LinearLayout.LayoutParams(0,dp(43),1f))
        nav.addView(btn("NEXT ›") { changeSection(1) },LinearLayout.LayoutParams(0,dp(43),1f))
        root.addView(nav)
        toggle=btn("OPEN ALL WINDOWS") { toggleSection() }
        root.addView(toggle,LinearLayout.LayoutParams(-1,dp(47)))
        val scroll=ScrollView(this)
        grid=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL }
        scroll.addView(grid)
        root.addView(scroll,LinearLayout.LayoutParams(-1,0,1f))
        fun renderLabel() { sectionLabel.text="${section*20+1}–${section*20+20} / 200" }
        labelUpdater={renderLabel()}; renderLabel(); render()
    }
    private var labelUpdater:(()->Unit)?=null
    private fun changeSection(delta:Int) { if(expanded!=null) collapse(); section=(section+delta).coerceIn(0,9); labelUpdater?.invoke();render() }
    private fun updateToggle(){ val all=(section*20+1..section*20+20).all { sessions.containsKey(it) };toggle.text=if(all) "CLOSE ALL WINDOWS" else "OPEN ALL WINDOWS" }
    private fun toggleSection(){ val range=(section*20+1)..(section*20+20);if(range.all {sessions.containsKey(it)})range.forEach { close(it) } else range.filterNot {sessions.containsKey(it)}.forEach { open(it) };updateToggle() }
    private fun render(){ grid.removeAllViews(); frames.clear()
        for(rowIndex in 0..9) {
            val row=LinearLayout(this)
            grid.addView(row)
            for(col in 0..1) {
                val id=section*20+rowIndex*2+col+1
                val card=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setPadding(dp(3),dp(3),dp(3),dp(6));setBackgroundColor(Color.rgb(32,20,33))}
                val header=LinearLayout(this).apply {gravity=Gravity.CENTER_VERTICAL}
                header.addView(text("YT $id"),LinearLayout.LayoutParams(0,dp(42),1f))
                val more=btn("⋮") { val anchor=frames[id] ?: return@btn; val popup=PopupMenu(this,anchor);popup.menu.add("Expand");popup.menu.add("Close");popup.setOnMenuItemClickListener { item->if(item.title=="Expand")expand(id) else close(id);true };popup.show() }
                header.addView(more,LinearLayout.LayoutParams(dp(48),dp(42)))
                card.addView(header)
                val frame=FrameLayout(this).apply {setBackgroundColor(Color.BLACK)}
                frames[id]=frame
                card.addView(frame,LinearLayout.LayoutParams(-1,dp(185)))
                row.addView(card,LinearLayout.LayoutParams(0,-2,1f).apply {setMargins(dp(3),dp(3),dp(3),dp(3))})
                if(sessions.containsKey(id)) attach(id,frame) else frame.addView(btn("Open window") {open(id)},FrameLayout.LayoutParams(-1,dp(54),Gravity.CENTER))
            }
        }
        updateToggle()
    }
    private fun attach(id:Int, frame:FrameLayout){ val browser=sessions[id]?:return;(browser.parent as? ViewGroup)?.removeView(browser);frame.removeAllViews();frame.addView(browser,FrameLayout.LayoutParams(-1,-1)) }
    private fun open(id:Int){if(sessions.containsKey(id))return
        if(!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)){Toast.makeText(this,"Multi-profile WebView unavailable",Toast.LENGTH_LONG).show();return}
        val browser=WebView(this)
        try { WebViewCompat.setProfile(browser,"alam_youtube_$id") } catch(e:Exception){browser.destroy();Toast.makeText(this,"Profile error: ${e.message}",Toast.LENGTH_LONG).show();return}
        browser.settings.javaScriptEnabled=true;browser.settings.domStorageEnabled=true;browser.settings.useWideViewPort=true;browser.settings.loadWithOverviewMode=true
        browser.settings.mediaPlaybackRequiresUserGesture=true
        browser.webViewClient=object:WebViewClient(){
            override fun onPageFinished(view:WebView,url:String){if(valid(url))prefs.edit().putString("last_$id",url).apply()}
            override fun shouldOverrideUrlLoading(view:WebView,request:WebResourceRequest):Boolean = request.url.scheme !in listOf("https","http")
        }
        sessions[id]=browser
        frames[id]?.let{attach(id,it)}
        val entered=urlInput.text.toString().trim()
        if(valid(entered))prefs.edit().putString("input_url",entered).apply()
        browser.loadUrl(if(valid(entered)) entered else prefs.getString("last_$id","https://m.youtube.com/")!!)
        updateToggle()
    }
    private fun close(id:Int){if(expanded==id)collapse();sessions.remove(id)?.let{(it.parent as? ViewGroup)?.removeView(it);it.stopLoading();it.destroy()};frames[id]?.let{frame->frame.removeAllViews();frame.addView(btn("Open window"){open(id)},FrameLayout.LayoutParams(-1,dp(54),Gravity.CENTER))};updateToggle()}
    private fun expand(id:Int){val browser=sessions[id]?:return;if(expanded!=null)return;expanded=id
        val frame=frames[id]?:return;(browser.parent as? ViewGroup)?.removeView(browser)
        val overlay=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;setBackgroundColor(bg);tag="expanded"}
        overlay.addView(btn("‹ BACK TO GRID") {collapse()},LinearLayout.LayoutParams(-1,dp(50)))
        overlay.addView(browser,LinearLayout.LayoutParams(-1,0,1f))
        root.addView(overlay,LinearLayout.LayoutParams(-1,0,1f))
        grid.visibility=View.INVISIBLE
        (grid.parent as? View)?.visibility=View.GONE
    }
    private fun collapse(){val id=expanded?:return;expanded=null
        val overlay=root.findViewWithTag<View>("expanded");(sessions[id]?.parent as? ViewGroup)?.removeView(sessions[id]);root.removeView(overlay)
        (grid.parent as? View)?.visibility=View.VISIBLE;grid.visibility=View.VISIBLE
        frames[id]?.let{attach(id,it)}
    }
    override fun onBackPressed(){if(expanded!=null)collapse() else super.onBackPressed()}
    override fun onDestroy(){sessions.values.forEach { (it.parent as? ViewGroup)?.removeView(it);it.destroy() };sessions.clear();super.onDestroy()}
}
