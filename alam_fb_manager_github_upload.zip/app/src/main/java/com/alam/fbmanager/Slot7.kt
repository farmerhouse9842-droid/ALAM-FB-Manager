package com.alam.fbmanager
class Slot7 : AccountActivity()
