package com.alam.fbmanager

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.ClipData
import android.content.ClipboardManager
import org.json.JSONArray
import android.media.AudioManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.MotionEvent
import android.webkit.WebSettings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.widget.*

/** Manual browser grid. WebViews in this Activity share browser cookies. */
class GridActivity : Activity() {
    // Best-effort page-level mute. Embedded cross-origin players may ignore it.
    private fun mutePage(view: WebView) {
        val js = """(function(){
          if(window.__alamMuteInstalled)return;
          window.__alamMuteInstalled=true;
          function mute(){document.querySelectorAll('video,audio').forEach(function(v){
            v.muted=true;v.defaultMuted=true;v.volume=0;
          });}
          mute();
          new MutationObserver(mute).observe(document.documentElement,{childList:true,subtree:true});
          document.addEventListener('play',mute,true);
          document.addEventListener('volumechange',mute,true);
        })();""".trimIndent()
        view.evaluateJavascript(js, null)
    }
    // Best effort: Facebook changes its markup often. Never submit comments automatically.
    private val pendingComments = mutableMapOf<Int, String?>()
    private fun focusComment(i: Int, draft: String? = null) {
        val web = browsers[i] ?: return
        val quoted = org.json.JSONObject.quote(draft ?: "")
        val js = """(function(){
          var draft=$quoted, tries=0;
          function visible(e){return !!(e && e.getClientRects().length && getComputedStyle(e).visibility!=='hidden');}
          function text(e){return ((e.getAttribute('aria-label')||'')+' '+(e.getAttribute('placeholder')||'')+' '+(e.getAttribute('data-placeholder')||'')).toLowerCase();}
          function findBox(){
            var nodes=Array.from(document.querySelectorAll('[contenteditable="true"],textarea,[role="textbox"],input[type="text"]')).filter(visible);
            return nodes.find(function(e){return /comment|মন্তব্য|reply|কমেন্ট/.test(text(e));}) ||
              nodes.find(function(e){return !!e.closest('[aria-label*="comment" i],[aria-label*="reply" i]');});
          }
          function apply(){
            var el=findBox();
            if(el){
              el.scrollIntoView({block:'center'});el.focus();
              if(draft){
                if(el.isContentEditable){el.textContent=draft;el.dispatchEvent(new InputEvent('input',{bubbles:true,inputType:'insertText',data:draft}));}
                else if(el.tagName==='TEXTAREA'||el.tagName==='INPUT'){
                  var proto=el.tagName==='TEXTAREA'?HTMLTextAreaElement.prototype:HTMLInputElement.prototype;
                  Object.getOwnPropertyDescriptor(proto,'value').set.call(el,draft);
                  el.dispatchEvent(new Event('input',{bubbles:true}));
                }
              }
              return;
            }
            if(tries++>=8)return;
            var buttons=Array.from(document.querySelectorAll('button,[role="button"],a')).filter(visible);
            var b=buttons.find(function(e){return /^(comment|মন্তব্য|কমেন্ট|write a comment|reply)$/i.test((e.innerText||e.getAttribute('aria-label')||'').trim());});
            if(b && tries===1)b.click();
            setTimeout(apply,550);
          }
          apply();
        })();""".trimIndent()
        web.evaluateJavascript(js, null)
        web.requestFocus()
    }
    private fun requestComment(i: Int, draft: String? = null) {
        if (!browsers.containsKey(i)) openWindow(i, useInputLink = true)
        val web = browsers[i] ?: return
        if (explicitLink && validUrl(selectedUrl) && web.url != selectedUrl) {
            pendingComments[i] = draft
            web.loadUrl(selectedUrl)
        } else {
            web.postDelayed({ focusComment(i, draft) }, 450)
        }
        if (expanded != i) expand(i)
    }
    private val bg = Color.rgb(4, 10, 25)
    private val cyan = Color.rgb(30, 207, 255)
    private lateinit var main: LinearLayout
    private lateinit var gridScreen: ScrollView
    private var expanded: Int? = null
    private val browsers = mutableMapOf<Int, WebView>()
    private val holders = mutableMapOf<Int, FrameLayout>()
    private val compactListeners = mutableMapOf<Int, View.OnLayoutChangeListener>()
    private var activePanel: LinearLayout? = null
    private var selectedUrl = "https://m.facebook.com/"
    private var explicitLink = false
    private val virtualWidthDp = 360
    private lateinit var allWindowsButton: Button
    private var windowCount = 20
    private var sectionIndex = 0
    private var sectionStart = 1
    private var gridContent: LinearLayout? = null
    private var soundOff = false
    private lateinit var soundButton: Button
    private var savedMediaVolume = -1
    private val pagePrefs by lazy { getSharedPreferences("window_last_pages", Context.MODE_PRIVATE) }
    private var selectedWindow = 1
    private val currentPages = mutableMapOf<Int, String>()

    private fun dp(n: Int) = (resources.displayMetrics.density * n).toInt()
    private fun panel(): GradientDrawable = GradientDrawable().apply {
        setColor(Color.rgb(12, 29, 56)); cornerRadius = dp(14).toFloat()
        setStroke(dp(1), Color.rgb(23, 105, 169))
    }
    private fun label(s: String, size: Float = 13f) = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(7), dp(7), dp(7), dp(7))
    }
    private fun action(s: String, click: () -> Unit) = Button(this).apply {
        text = s; textSize = 11f; setAllCaps(false); setOnClickListener { click() }
    }
    private fun validUrl(value: String): Boolean = try {
        val uri = android.net.Uri.parse(value)
        uri.scheme == "https" && (uri.host?.lowercase() == "fb.watch" || uri.host?.lowercase() == "facebook.com" || uri.host?.lowercase()?.endsWith(".facebook.com") == true)
    } catch (_: Exception) { false }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        val incoming = intent.getStringExtra("video_url").orEmpty()
        if (validUrl(incoming)) { selectedUrl = incoming; explicitLink = true }
        val count = intent.getIntExtra("account_count", 20).coerceIn(1, 200)
        sectionIndex = intent.getIntExtra("section_index", 0).coerceIn(0, (count - 1) / 20)
        windowCount = minOf(20, count - sectionIndex * 20)
        sectionStart = sectionIndex * 20 + 1
        selectedWindow = sectionStart
        val cols = if (intent.getBooleanExtra("grid_mode", true)) 2 else 1
        main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        setContentView(main)
        gridScreen = ScrollView(this).apply { isFillViewport = true; isSmoothScrollingEnabled = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(12), dp(10), dp(20)) }
        gridScreen.addView(content)
        gridContent = content
        content.addView(label("ALAM FB  •  WINDOWS", 16f).apply { setTextColor(cyan); setPadding(dp(4), dp(2), dp(4), dp(2)) })
        content.addView(label("Accounts $sectionStart–${sectionStart + windowCount - 1}", 12f).apply { setPadding(dp(4), 0, dp(4), dp(3)) })
        allWindowsButton = action("OPEN ALL WINDOWS") { toggleAllWindows() }.apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(10, 112, 83))
        }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        controls.addView(allWindowsButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            setMargins(dp(3), dp(4), dp(3), dp(9))
        })
        val refreshButton = action("⟳") { refreshSelectedWindow() }.apply {
            textSize = 23f
            contentDescription = "Refresh selected window"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(27, 73, 121))
        }
        controls.addView(refreshButton, LinearLayout.LayoutParams(dp(52), dp(48)).apply {
            setMargins(dp(2), dp(4), dp(3), dp(9))
        })
        content.addView(controls, LinearLayout.LayoutParams(-1, -2))
        val refreshGridButton = action("↻ REFRESH GRID VIEW") { refreshGridView() }.apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(25, 83, 112))
        }
        content.addView(refreshGridButton, LinearLayout.LayoutParams(-1, dp(43)).apply {
            setMargins(dp(3), 0, dp(3), dp(8))
        })
        // Compact draft tools live on the window page. Existing WebViews are untouched.
        val draftPrefs = getSharedPreferences("comment_drafts", MODE_PRIVATE)
        val draftBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = panel()
            setPadding(dp(7), dp(5), dp(7), dp(5))
        }
        draftBox.addView(label("COMMENT DRAFT", 12f).apply { setTextColor(cyan); setPadding(dp(3), 0, dp(3), dp(3)) })
        val draftInput = EditText(this).apply {
            hint = "Write a comment to save or copy"
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            minLines = 1
            maxLines = 2
            gravity = Gravity.TOP
            setBackgroundColor(Color.rgb(7, 21, 43))
            setPadding(dp(8), dp(4), dp(8), dp(4))
        }
        draftBox.addView(draftInput, LinearLayout.LayoutParams(-1, -2))
        // Explicit selection for comment navigation; only slots in the current section.
        val windowChoices = (sectionStart until sectionStart + windowCount).toList()
        val selectRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        selectRow.addView(label("WINDOW", 11f).apply {
            setTextColor(cyan)
        }, LinearLayout.LayoutParams(-2, dp(40)))
        val windowPicker = Spinner(this)
        val pickerAdapter = ArrayAdapter(
            this, android.R.layout.simple_spinner_item,
            windowChoices.map { "Window $it" }
        ).apply { setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }
        windowPicker.adapter = pickerAdapter
        windowPicker.setSelection((selectedWindow - sectionStart).coerceIn(0, windowChoices.lastIndex))
        windowPicker.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                selectedWindow = windowChoices[position]
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }
        selectRow.addView(windowPicker, LinearLayout.LayoutParams(0, dp(43), 1f))
        draftBox.addView(selectRow, LinearLayout.LayoutParams(-1, dp(43)))
        val draftActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        draftActions.addView(action("SAVE DRAFT") {
            val value = draftInput.text.toString().trim()
            if (value.isNotEmpty()) {
                val array = try { JSONArray(draftPrefs.getString("drafts", "[]")) } catch (_: Exception) { JSONArray() }
                array.put(value)
                draftPrefs.edit().putString("drafts", array.toString()).apply()
                Toast.makeText(this, "Draft saved", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(0, dp(36), 1f))
        draftActions.addView(action("COPY") {
            val value = draftInput.text.toString().trim()
            if (value.isNotEmpty()) {
                (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager)
                    .setPrimaryClip(ClipData.newPlainText("Comment draft", value))
                Toast.makeText(this, "Copied", Toast.LENGTH_SHORT).show()
            }
        }, LinearLayout.LayoutParams(0, dp(36), 1f))
        draftActions.addView(action("DRAFTS") {
            startActivity(android.content.Intent(this, CommentsActivity::class.java))
        }, LinearLayout.LayoutParams(0, dp(36), 1f))
        draftBox.addView(draftActions)
        val goToPost = action("GO TO POST / COMMENTS") {
            if (!explicitLink || !validUrl(selectedUrl)) {
                Toast.makeText(this, "Enter a Facebook post link on Home first", Toast.LENGTH_LONG).show()
            } else {
                // Open only the selected account, leaving all other windows untouched.
                if (!browsers.containsKey(selectedWindow)) {
                    openWindow(selectedWindow, useInputLink = true)
                } else if (browsers[selectedWindow]?.url != selectedUrl) {
                    browsers[selectedWindow]?.loadUrl(selectedUrl)
                }
                requestComment(selectedWindow)
            }
        }.apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(14, 104, 147))
        }
        draftBox.addView(goToPost, LinearLayout.LayoutParams(-1, dp(39)).apply {
            setMargins(0, dp(3), 0, 0)
        })
        content.addView(draftBox, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(3), dp(4), dp(3), dp(6)) })
        val openLinkButton = action("OPEN LINK IN SELECTED WINDOW") { openLinkInSelectedWindow() }.apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(15, 89, 140))
        }
        content.addView(openLinkButton, LinearLayout.LayoutParams(-1, dp(44)).apply {
            setMargins(dp(3), 0, dp(3), dp(8))
        })
        val openShareLinks = action("PREPARE SHARE IN ALL 20 WINDOWS") {
            if (!explicitLink || !validUrl(selectedUrl)) {
                Toast.makeText(this, "Enter a valid Facebook link on Home", Toast.LENGTH_LONG).show()
            } else {
                for (i in sectionStart until sectionStart + windowCount) {
                    if (!browsers.containsKey(i)) openWindow(i, useInputLink = true)
                    val shareUrl = "https://www.facebook.com/sharer/sharer.php?u=" +
                        android.net.Uri.encode(selectedUrl)
                    browsers[i]?.loadUrl(shareUrl)
                }
                Toast.makeText(this, "Share pages prepared. Confirm each share in Facebook.", Toast.LENGTH_LONG).show()
            }
        }.apply { textSize = 12f; setTextColor(Color.WHITE); setBackgroundColor(Color.rgb(210, 22, 43)) }
        content.addView(openShareLinks, LinearLayout.LayoutParams(-1, dp(49)).apply { setMargins(dp(3), dp(4), dp(3), dp(8)) })
        val checkButton = action("CHECK ALL WINDOWS") { checkAllWindows() }.apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(25, 83, 112))
        }
        content.addView(checkButton, LinearLayout.LayoutParams(-1, dp(43)).apply {
            setMargins(dp(3), 0, dp(3), dp(8))
        })
        soundButton = action("SOUND OFF (DEVICE)") { toggleDeviceSound() }.apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(27, 73, 121))
        }
        content.addView(soundButton, LinearLayout.LayoutParams(-1, dp(46)).apply {
            setMargins(dp(3), 0, dp(3), dp(8))
        })
        var row: LinearLayout? = null
        for (i in sectionStart until (sectionStart + windowCount)) {
            if ((i - sectionStart) % cols == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                content.addView(row, LinearLayout.LayoutParams(-1, -2))
            }
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = panel(); setPadding(dp(3), dp(3), dp(3), dp(5)) }
            val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val windowLabel = label("Window $i", 12f)
            windowLabel.setOnClickListener {
                selectedWindow = i
                windowPicker.setSelection(i - sectionStart)
                Toast.makeText(this, "Window $i selected", Toast.LENGTH_SHORT).show()
            }
            header.addView(windowLabel, LinearLayout.LayoutParams(0, -2, 1f))
            val menu = TextView(this).apply { text = "⋮"; textSize = 23f; setTextColor(cyan); gravity = Gravity.CENTER; setPadding(dp(9), 0, dp(9), 0) }
            header.addView(menu)
            card.addView(header)
            val holder = FrameLayout(this).apply { setBackgroundColor(Color.rgb(6, 16, 31)) }
            holders[i] = holder
            card.addView(holder, LinearLayout.LayoutParams(-1, dp(if (cols == 2) 170 else 230)))
            val socialActions = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            fun socialButton(title: String, instruction: String): Button = action(title) {
                selectedWindow = i
                windowPicker.setSelection(i - sectionStart)
                val browser = browsers[i]
                val postUrl = if (explicitLink && validUrl(selectedUrl)) selectedUrl
                    else browser?.url?.takeIf { validUrl(it) }
                    ?: currentPages[i]?.takeIf { validUrl(it) }
                if (title == "SHARE") {
                    if (!validUrl(postUrl ?: "")) {
                        Toast.makeText(this, "Enter a Facebook post link first", Toast.LENGTH_LONG).show()
                    } else {
                        if (browser == null) openWindow(i, useInputLink = true)
                        expand(i)
                        // Official Facebook web sharing endpoint. The user reviews and
                        // confirms the post in Facebook; no automated publishing.
                        val shareUrl = "https://www.facebook.com/sharer/sharer.php?u=" +
                            android.net.Uri.encode(postUrl)
                        browsers[i]?.loadUrl(shareUrl)
                            ?: Toast.makeText(this, "Open the window and tap SHARE again", Toast.LENGTH_LONG).show()
                    }
                } else if (title == "COMMENT") {
                    requestComment(i)
                } else {
                    if (browser == null) openWindow(i, useInputLink = true)
                    else if (explicitLink && validUrl(selectedUrl) && browser.url != selectedUrl) browser.loadUrl(selectedUrl)
                    expand(i)
                    Toast.makeText(this, instruction, Toast.LENGTH_LONG).show()
                }
            }.apply {
                textSize = 10f
                setTextColor(Color.WHITE)
                setPadding(0, 0, 0, 0)
                setBackgroundColor(Color.rgb(210, 22, 43))
            }
            socialActions.addView(socialButton("LIKE", "Tap Like on the Facebook post"), LinearLayout.LayoutParams(0, dp(38), 1f))
            socialActions.addView(socialButton("COMMENT", "Tap Comment on the Facebook post"), LinearLayout.LayoutParams(0, dp(38), 1.35f).apply { setMargins(dp(2), 0, dp(2), 0) })
            socialActions.addView(socialButton("SHARE", "Confirm share in Facebook"), LinearLayout.LayoutParams(0, dp(38), 1f))
            card.addView(socialActions, LinearLayout.LayoutParams(-1, dp(38)))
            val open = action("Open window") { openWindow(i) }
            holder.addView(open, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
            menu.setOnClickListener {
                val pop = PopupMenu(this, menu)
                pop.menu.add("Expand window")
                pop.menu.add("Close window")
                pop.setOnMenuItemClickListener { item ->
                    if (item.title == "Expand window") expand(i) else closeWindow(i)
                    true
                }
                pop.show()
            }
            row!!.addView(card, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(5)) })
        }
        main.addView(gridScreen, LinearLayout.LayoutParams(-1, 0, 1f))
        val requestedWindow = intent.getIntExtra("open_selected_comment_window", -1)
        val requestedDraft = intent.getStringExtra("selected_comment_draft")
        if (requestedWindow in sectionStart until (sectionStart + windowCount)) {
            selectedWindow = requestedWindow
            gridScreen.post {
                pendingComments[requestedWindow] = requestedDraft
                openWindow(requestedWindow, useInputLink = true)
                if (browsers[requestedWindow]?.progress == 100) requestComment(requestedWindow, requestedDraft)
            }
        }

    }

    // Android WebView does not expose a reliable per-WebView mute API.
    // This button controls the phone's shared media volume, not individual windows.
    private fun toggleDeviceSound() {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (!soundOff) {
            savedMediaVolume = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)
            soundOff = true
        } else {
            if (savedMediaVolume >= 0) audio.setStreamVolume(AudioManager.STREAM_MUSIC, savedMediaVolume, 0)
            soundOff = false
        }
        soundButton.text = if (soundOff) "SOUND ON (DEVICE)" else "SOUND OFF (DEVICE)"
        Toast.makeText(this, "Changes phone media volume for all apps", Toast.LENGTH_SHORT).show()
    }

    /** Repaint only the grid chrome; never recreate or reload live WebViews. */
    private fun refreshGridView() {
        updateAllButton()
        gridContent?.invalidate()
        gridContent?.requestLayout()
        holders.values.forEach { it.invalidate() }
        Toast.makeText(this, "Grid refreshed; open browser pages unchanged", Toast.LENGTH_SHORT).show()
    }

    private fun checkAllWindows() {
        val openCount = browsers.size
        val loadingCount = browsers.values.count { it.progress < 100 }
        val message = "Open: $openCount/$windowCount  •  Loading: $loadingCount  •  Closed: ${windowCount - openCount}"
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun openLinkInSelectedWindow() {
        if (!explicitLink || !validUrl(selectedUrl)) {
            Toast.makeText(this, "Enter a Facebook profile/photo link on Home first", Toast.LENGTH_LONG).show()
            return
        }
        if (!browsers.containsKey(selectedWindow)) {
            openWindow(selectedWindow, useInputLink = true)
        } else {
            browsers[selectedWindow]?.loadUrl(selectedUrl)
        }
        Toast.makeText(this, "Opened link in Window $selectedWindow", Toast.LENGTH_SHORT).show()
    }

    private fun refreshSelectedWindow() {
        val browser = browsers[selectedWindow]
        if (browser == null) {
            Toast.makeText(this, "Open Window $selectedWindow first", Toast.LENGTH_SHORT).show()
        } else {
            browser.reload()
        }
    }

    private fun lastPage(i: Int): String =
        currentPages[i]
            ?: pagePrefs.getString("url_$i", null)?.takeIf { validUrl(it) }
            ?: "https://m.facebook.com/"

    private fun savePage(i: Int, browser: WebView) {
        val url = browser.url.orEmpty()
        if (validUrl(url)) {
            currentPages[i] = url
            pagePrefs.edit().putString("url_$i", url).apply()
        }
    }


    private fun updateAllButton() {
        if (!::allWindowsButton.isInitialized) return
        val allOpen = (sectionStart until (sectionStart + windowCount)).all { browsers.containsKey(it) }
        allWindowsButton.text = if (allOpen) "CLOSE ALL WINDOWS" else "OPEN ALL WINDOWS"
        allWindowsButton.setBackgroundColor(if (allOpen) Color.rgb(150, 36, 57) else Color.rgb(10, 112, 83))
    }

    private fun toggleAllWindows() {
        if ((sectionStart until (sectionStart + windowCount)).all { browsers.containsKey(it) }) {
            for (i in sectionStart until (sectionStart + windowCount)) closeWindow(i)
        } else {
            // Restore each independent browser's own saved page in the grid.
            for (i in sectionStart until (sectionStart + windowCount)) if (!browsers.containsKey(i)) openWindow(i, useInputLink = false)
        }
        updateAllButton()
    }

    private fun openWindow(i: Int, useInputLink: Boolean = true) {
        if (browsers.containsKey(i)) return
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            Toast.makeText(this, "Independent WebView profiles not supported", Toast.LENGTH_LONG).show()
            return
        }
        val browser = WebView(this)
        try {
            // Must be assigned before configuring or navigating the WebView.
            WebViewCompat.setProfile(browser, "alam_account_$i")
        } catch (e: Exception) {
            browser.destroy()
            Toast.makeText(this, "Profile setup failed: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }
        // Let the embedded browser consume swipe gestures rather than the outer grid.
        // Returning false keeps native WebView taps, scrolling and text entry working.
        browser.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE ->
                    view.parent?.requestDisallowInterceptTouchEvent(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }
        browser.isVerticalScrollBarEnabled = true
        browser.isHorizontalScrollBarEnabled = false
        browser.settings.javaScriptEnabled = true
        browser.settings.domStorageEnabled = true
        browser.settings.useWideViewPort = true
        browser.settings.loadWithOverviewMode = true
        browser.settings.builtInZoomControls = true
        browser.settings.displayZoomControls = false
        browser.settings.textZoom = 100
        browser.settings.layoutAlgorithm = WebSettings.LayoutAlgorithm.NORMAL
        browser.overScrollMode = View.OVER_SCROLL_NEVER
        browser.settings.mediaPlaybackRequiresUserGesture = false
        // Facebook controls stream resolution. Prefer data-saving browsing, but no fixed 144p/240p override is available.
        browser.setLayerType(View.LAYER_TYPE_HARDWARE, null)
        browser.isFocusable = true
        browser.isFocusableInTouchMode = true
        browser.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                mutePage(view)
                if (pendingComments.containsKey(i)) {
                    val draft = pendingComments.remove(i)
                    view.postDelayed({ focusComment(i, draft) }, 850)
                }
                if (validUrl(url)) {
                    currentPages[i] = url
                    pagePrefs.edit().putString("url_$i", url).apply()
                }
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return request.url.scheme != "https" && request.url.scheme != "http"
            }
        }
        browsers[i] = browser
        val holder = holders[i] ?: return
        holder.removeAllViews()
        attachCompactBrowser(i, browser)
        browser.loadUrl(if (useInputLink && explicitLink && validUrl(selectedUrl)) selectedUrl else lastPage(i))
        updateAllButton()
    }
    /**
     * Render a normal phone-width viewport, then scale the entire WebView into
     * its small card. Android's view transform also maps touch coordinates,
     * so links, taps and scrolling remain usable in compact mode.
     * No page CSS, JavaScript or Facebook playback behavior is modified.
     */
    private fun detachCompactListener(i: Int) {
        val holder = holders[i] ?: return
        compactListeners.remove(i)?.let { holder.removeOnLayoutChangeListener(it) }
    }

    /** Keep the same WebView instance and its independent profile when resizing.
     * Avoid accumulating layout callbacks across expand/back cycles.
     */
    private fun attachCompactBrowser(i: Int, browser: WebView) {
        val holder = holders[i] ?: return
        detachCompactListener(i)
        (browser.parent as? ViewGroup)?.removeView(browser)
        holder.removeAllViews()
        holder.clipChildren = true
        holder.clipToPadding = true
        browser.pivotX = 0f
        browser.pivotY = 0f
        val virtualWidth = dp(virtualWidthDp)
        holder.addView(browser, FrameLayout.LayoutParams(virtualWidth, dp(340)))
        val listener = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (browser.parent !== holder || holder.width <= 0 || holder.height <= 0) return@OnLayoutChangeListener
            val factor = (holder.width.toFloat() / virtualWidth).coerceIn(0.1f, 1f)
            val height = (holder.height / factor).toInt().coerceAtLeast(1)
            val lp = browser.layoutParams as FrameLayout.LayoutParams
            if (lp.width != virtualWidth || lp.height != height) {
                lp.width = virtualWidth
                lp.height = height
                browser.layoutParams = lp
            }
            if (browser.scaleX != factor || browser.scaleY != factor) {
                browser.scaleX = factor
                browser.scaleY = factor
            }
        }
        compactListeners[i] = listener
        holder.addOnLayoutChangeListener(listener)
        holder.post { if (browser.parent === holder) {
            val factor = (holder.width.toFloat() / virtualWidth).coerceIn(0.1f, 1f)
            val lp = browser.layoutParams as FrameLayout.LayoutParams
            lp.height = (holder.height / factor).toInt().coerceAtLeast(1)
            browser.layoutParams = lp
            browser.scaleX = factor
            browser.scaleY = factor
        } }
    }

    private fun closeWindow(i: Int) {
        if (expanded == i) restoreGrid()
        detachCompactListener(i)
        browsers.remove(i)?.let { web -> savePage(i, web); (web.parent as? ViewGroup)?.removeView(web); web.destroy() }
        holders[i]?.apply {
            removeAllViews()
            addView(action("Open window") { openWindow(i) }, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        }
        updateAllButton()
    }
    private fun expand(i: Int) {
        if (!browsers.containsKey(i)) openWindow(i, useInputLink = false)
        val browser = browsers[i] ?: return
        detachCompactListener(i)
        (browser.parent as? ViewGroup)?.removeView(browser)
        gridScreen.visibility = View.GONE
        expanded = i
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        activePanel = panel
        panel.addView(action("← Back to small windows") { restoreGrid() }, LinearLayout.LayoutParams(-1, dp(52)))
        browser.scaleX = 1f
        browser.scaleY = 1f
        panel.addView(browser, LinearLayout.LayoutParams(-1, 0, 1f))
        main.addView(panel, LinearLayout.LayoutParams(-1, 0, 1f))
    }
    private fun restoreGrid() {
        val i = expanded ?: return
        val browser = browsers[i]
        if (browser != null) {
            (browser.parent as? ViewGroup)?.removeView(browser)
            attachCompactBrowser(i, browser)
            // Do not force an old pixel scroll offset after resizing: the site
            // may have reflowed and restoring it can jump to the wrong content.
        }
        activePanel?.let { main.removeView(it) }
        activePanel = null
        expanded = null
        gridScreen.visibility = View.VISIBLE
    }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (expanded != null) restoreGrid() else super.onBackPressed()
    }
    override fun onDestroy() {
        compactListeners.keys.toList().forEach { detachCompactListener(it) }
        browsers.forEach { (i, web) -> savePage(i, web); (web.parent as? ViewGroup)?.removeView(web); web.destroy() }
        browsers.clear()
        // Restore the original media volume when leaving the grid.
        if (soundOff && savedMediaVolume >= 0) {
            (getSystemService(Context.AUDIO_SERVICE) as AudioManager).setStreamVolume(AudioManager.STREAM_MUSIC, savedMediaVolume, 0)
        }
        super.onDestroy()
    }
}
