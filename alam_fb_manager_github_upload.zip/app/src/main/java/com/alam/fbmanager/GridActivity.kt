package com.alam.fbmanager

import android.app.Activity
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.MotionEvent
import android.webkit.WebSettings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.widget.*

/** Manual browser grid. WebViews in this Activity share browser cookies. */
class GridActivity : Activity() {
    private val bg = Color.rgb(4, 10, 25)
    private val cyan = Color.rgb(30, 207, 255)
    private lateinit var main: LinearLayout
    private lateinit var gridScreen: ScrollView
    private var expanded: Int? = null
    private val browsers = mutableMapOf<Int, WebView>()
    private val holders = mutableMapOf<Int, FrameLayout>()
    private var activePanel: LinearLayout? = null
    private var selectedUrl = "https://m.facebook.com/"
    private val virtualWidthDp = 360

    private fun dp(n: Int) = (resources.displayMetrics.density * n).toInt()
    private fun panel(): GradientDrawable = GradientDrawable().apply {
        setColor(Color.rgb(12, 29, 56)); cornerRadius = dp(14).toFloat()
        setStroke(dp(1), Color.rgb(23, 105, 169))
    }
    private fun label(s: String, size: Float = 13f) = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(7), dp(7), dp(7), dp(7))
    }
    private fun action(s: String, click: () -> Unit) = Button(this).apply {
        text = s; textSize = 11f; setAllCaps(false); setOnClickListener { click() }
    }
    private fun validUrl(value: String): Boolean = try {
        val uri = android.net.Uri.parse(value)
        uri.scheme == "https" && (uri.host?.lowercase() == "fb.watch" || uri.host?.lowercase() == "facebook.com" || uri.host?.lowercase()?.endsWith(".facebook.com") == true)
    } catch (_: Exception) { false }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        val incoming = intent.getStringExtra("video_url").orEmpty()
        if (validUrl(incoming)) selectedUrl = incoming
        val count = intent.getIntExtra("account_count", 10).let { if (it == 20) 20 else 10 }
        val cols = if (intent.getBooleanExtra("grid_mode", true)) 2 else 1
        main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        setContentView(main)
        gridScreen = ScrollView(this).apply { isFillViewport = true; isSmoothScrollingEnabled = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(12), dp(10), dp(20)) }
        gridScreen.addView(content)
        content.addView(label("ALAM FB MANAGER  •  MANUAL WINDOWS", 19f).apply { setTextColor(cyan) })
        content.addView(label("Independent browser profiles. Open each window manually. Touch to scroll inside; use 3 dots to expand or close.", 12f))
        var row: LinearLayout? = null
        for (i in 1..count) {
            if ((i - 1) % cols == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                content.addView(row, LinearLayout.LayoutParams(-1, -2))
            }
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = panel(); setPadding(dp(3), dp(3), dp(3), dp(5)) }
            val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            header.addView(label("Window $i", 12f), LinearLayout.LayoutParams(0, -2, 1f))
            val menu = TextView(this).apply { text = "⋮"; textSize = 23f; setTextColor(cyan); gravity = Gravity.CENTER; setPadding(dp(9), 0, dp(9), 0) }
            header.addView(menu)
            card.addView(header)
            val holder = FrameLayout(this).apply { setBackgroundColor(Color.rgb(6, 16, 31)) }
            holders[i] = holder
            card.addView(holder, LinearLayout.LayoutParams(-1, dp(if (cols == 2) 170 else 230)))
            val open = action("Open window") { openWindow(i) }
            holder.addView(open, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
            menu.setOnClickListener {
                val pop = PopupMenu(this, menu)
                pop.menu.add("Expand window")
                pop.menu.add("Close window")
                pop.setOnMenuItemClickListener { item ->
                    if (item.title == "Expand window") expand(i) else closeWindow(i)
                    true
                }
                pop.show()
            }
            row!!.addView(card, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(5)) })
        }
        main.addView(gridScreen, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    private fun openWindow(i: Int) {
        if (browsers.containsKey(i)) return
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            Toast.makeText(this, "Independent WebView profiles not supported", Toast.LENGTH_LONG).show()
            return
        }
        val browser = WebView(this)
        try {
            // Must be assigned before configuring or navigating the WebView.
            WebViewCompat.setProfile(browser, "alam_account_$i")
        } catch (e: Exception) {
            browser.destroy()
            Toast.makeText(this, "Profile setup failed: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }
        // Let the embedded browser consume swipe gestures rather than the outer grid.
        // Returning false keeps native WebView taps, scrolling and text entry working.
        browser.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE ->
                    view.parent?.requestDisallowInterceptTouchEvent(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }
        browser.isVerticalScrollBarEnabled = true
        browser.isHorizontalScrollBarEnabled = false
        browser.settings.javaScriptEnabled = true
        browser.settings.domStorageEnabled = true
        browser.settings.useWideViewPort = true
        browser.settings.loadWithOverviewMode = true
        browser.settings.builtInZoomControls = true
        browser.settings.displayZoomControls = false
        browser.settings.textZoom = 100
        browser.settings.layoutAlgorithm = WebSettings.LayoutAlgorithm.NORMAL
        browser.overScrollMode = View.OVER_SCROLL_NEVER
        browser.settings.mediaPlaybackRequiresUserGesture = true
        browser.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return request.url.scheme != "https" && request.url.scheme != "http"
            }
        }
        browsers[i] = browser
        val holder = holders[i] ?: return
        holder.removeAllViews()
        attachCompactBrowser(i, browser)
        browser.loadUrl(selectedUrl)
    }
    /**
     * Render a normal phone-width viewport, then scale the entire WebView into
     * its small card. Android's view transform also maps touch coordinates,
     * so links, taps and scrolling remain usable in compact mode.
     * No page CSS, JavaScript or Facebook playback behavior is modified.
     */
    private fun attachCompactBrowser(i: Int, browser: WebView) {
        val holder = holders[i] ?: return
        (browser.parent as? ViewGroup)?.removeView(browser)
        holder.removeAllViews()
        holder.clipChildren = true
        holder.clipToPadding = true
        browser.pivotX = 0f
        browser.pivotY = 0f
        val virtualWidth = dp(virtualWidthDp)
        val layout = FrameLayout.LayoutParams(virtualWidth, holder.height.coerceAtLeast(dp(170)))
        holder.addView(browser, layout)
        val update: () -> Unit = {
            if (browser.parent === holder && holder.width > 0 && holder.height > 0) {
                val factor = (holder.width.toFloat() / virtualWidth).coerceAtMost(1f)
                val requiredHeight = (holder.height / factor).toInt().coerceAtLeast(1)
                val params = browser.layoutParams as FrameLayout.LayoutParams
                if (params.width != virtualWidth || params.height != requiredHeight) {
                    params.width = virtualWidth
                    params.height = requiredHeight
                    browser.layoutParams = params
                }
                browser.scaleX = factor
                browser.scaleY = factor
            }
        }
        holder.addOnLayoutChangeListener { _, _, _, _, _, _, _, _, _ -> update() }
        holder.post { update() }
    }

    private fun closeWindow(i: Int) {
        if (expanded == i) restoreGrid()
        browsers.remove(i)?.let { web -> (web.parent as? ViewGroup)?.removeView(web); web.destroy() }
        holders[i]?.apply {
            removeAllViews()
            addView(action("Open window") { openWindow(i) }, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        }
    }
    private fun expand(i: Int) {
        if (!browsers.containsKey(i)) openWindow(i)
        val browser = browsers[i] ?: return
        (browser.parent as? ViewGroup)?.removeView(browser)
        gridScreen.visibility = View.GONE
        expanded = i
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        activePanel = panel
        panel.addView(action("← Back to small windows") { restoreGrid() }, LinearLayout.LayoutParams(-1, dp(52)))
        browser.scaleX = 1f
        browser.scaleY = 1f
        panel.addView(browser, LinearLayout.LayoutParams(-1, 0, 1f))
        main.addView(panel, LinearLayout.LayoutParams(-1, 0, 1f))
    }
    private fun restoreGrid() {
        val i = expanded ?: return
        val browser = browsers[i]
        if (browser != null) {
            (browser.parent as? ViewGroup)?.removeView(browser)
            attachCompactBrowser(i, browser)
            // Do not force an old pixel scroll offset after resizing: the site
            // may have reflowed and restoring it can jump to the wrong content.
        }
        activePanel?.let { main.removeView(it) }
        activePanel = null
        expanded = null
        gridScreen.visibility = View.VISIBLE
    }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (expanded != null) restoreGrid() else super.onBackPressed()
    }
    override fun onDestroy() {
        browsers.values.forEach { (it.parent as? ViewGroup)?.removeView(it); it.destroy() }
        browsers.clear()
        super.onDestroy()
    }
}
