package com.alam.fbmanager

import android.app.Activity
import android.content.Context
import android.media.AudioManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.MotionEvent
import android.webkit.WebSettings
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.webkit.WebView
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import android.webkit.WebViewClient
import android.webkit.WebResourceRequest
import android.widget.*

/** Manual browser grid. WebViews in this Activity share browser cookies. */
class GridActivity : Activity() {
    private val bg = Color.rgb(4, 10, 25)
    private val cyan = Color.rgb(30, 207, 255)
    private lateinit var main: LinearLayout
    private lateinit var gridScreen: ScrollView
    private var expanded: Int? = null
    private val browsers = mutableMapOf<Int, WebView>()
    private val holders = mutableMapOf<Int, FrameLayout>()
    private val compactListeners = mutableMapOf<Int, View.OnLayoutChangeListener>()
    private var activePanel: LinearLayout? = null
    private var selectedUrl = "https://m.facebook.com/"
    private var explicitLink = false
    private val virtualWidthDp = 360
    private lateinit var allWindowsButton: Button
    private var windowCount = 10
    private var gridContent: LinearLayout? = null
    private var soundOff = false
    private lateinit var soundButton: Button
    private var savedMediaVolume = -1
    private val pagePrefs by lazy { getSharedPreferences("window_last_pages", Context.MODE_PRIVATE) }
    private var selectedWindow = 1
    private val currentPages = mutableMapOf<Int, String>()

    private fun dp(n: Int) = (resources.displayMetrics.density * n).toInt()
    private fun panel(): GradientDrawable = GradientDrawable().apply {
        setColor(Color.rgb(12, 29, 56)); cornerRadius = dp(14).toFloat()
        setStroke(dp(1), Color.rgb(23, 105, 169))
    }
    private fun label(s: String, size: Float = 13f) = TextView(this).apply {
        text = s; textSize = size; setTextColor(Color.WHITE)
        gravity = Gravity.CENTER_VERTICAL; setPadding(dp(7), dp(7), dp(7), dp(7))
    }
    private fun action(s: String, click: () -> Unit) = Button(this).apply {
        text = s; textSize = 11f; setAllCaps(false); setOnClickListener { click() }
    }
    private fun validUrl(value: String): Boolean = try {
        val uri = android.net.Uri.parse(value)
        uri.scheme == "https" && (uri.host?.lowercase() == "fb.watch" || uri.host?.lowercase() == "facebook.com" || uri.host?.lowercase()?.endsWith(".facebook.com") == true)
    } catch (_: Exception) { false }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = bg
        val incoming = intent.getStringExtra("video_url").orEmpty()
        if (validUrl(incoming)) { selectedUrl = incoming; explicitLink = true }
        val count = intent.getIntExtra("account_count", 10).coerceIn(1, 200).coerceAtMost(20)
        windowCount = count
        val cols = if (intent.getBooleanExtra("grid_mode", true)) 2 else 1
        main = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        setContentView(main)
        gridScreen = ScrollView(this).apply { isFillViewport = true; isSmoothScrollingEnabled = false }
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(10), dp(12), dp(10), dp(20)) }
        gridScreen.addView(content)
        gridContent = content
        content.addView(label("ALAM FB MANAGER  •  MANUAL WINDOWS", 19f).apply { setTextColor(cyan) })
        content.addView(label("Independent browser profiles. Touch to scroll inside; use 3 dots to expand or close.", 12f))
        allWindowsButton = action("OPEN ALL WINDOWS") { toggleAllWindows() }.apply {
            textSize = 14f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(10, 112, 83))
        }
        val controls = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        controls.addView(allWindowsButton, LinearLayout.LayoutParams(0, dp(48), 1f).apply {
            setMargins(dp(3), dp(4), dp(3), dp(9))
        })
        val refreshButton = action("⟳") { refreshSelectedWindow() }.apply {
            textSize = 23f
            contentDescription = "Refresh selected window"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(27, 73, 121))
        }
        controls.addView(refreshButton, LinearLayout.LayoutParams(dp(52), dp(48)).apply {
            setMargins(dp(2), dp(4), dp(3), dp(9))
        })
        content.addView(controls, LinearLayout.LayoutParams(-1, -2))
        val refreshGridButton = action("↻ REFRESH GRID VIEW") { refreshGridView() }.apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(25, 83, 112))
        }
        content.addView(refreshGridButton, LinearLayout.LayoutParams(-1, dp(43)).apply {
            setMargins(dp(3), 0, dp(3), dp(8))
        })
        content.addView(label("Profile/photo links: choose a Window title, then tap OPEN LINK. Other windows stay unchanged.", 11f))
        val openLinkButton = action("OPEN LINK IN SELECTED WINDOW") { openLinkInSelectedWindow() }.apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(15, 89, 140))
        }
        content.addView(openLinkButton, LinearLayout.LayoutParams(-1, dp(44)).apply {
            setMargins(dp(3), 0, dp(3), dp(8))
        })
        val checkButton = action("CHECK ALL WINDOWS") { checkAllWindows() }.apply {
            textSize = 12f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(25, 83, 112))
        }
        content.addView(checkButton, LinearLayout.LayoutParams(-1, dp(43)).apply {
            setMargins(dp(3), 0, dp(3), dp(8))
        })
        soundButton = action("SOUND OFF (DEVICE)") { toggleDeviceSound() }.apply {
            textSize = 13f
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(27, 73, 121))
        }
        content.addView(soundButton, LinearLayout.LayoutParams(-1, dp(46)).apply {
            setMargins(dp(3), 0, dp(3), dp(8))
        })
        var row: LinearLayout? = null
        for (i in 1..count) {
            if ((i - 1) % cols == 0) {
                row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                content.addView(row, LinearLayout.LayoutParams(-1, -2))
            }
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; background = panel(); setPadding(dp(3), dp(3), dp(3), dp(5)) }
            val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            val windowLabel = label("Window $i", 12f)
            windowLabel.setOnClickListener {
                selectedWindow = i
                Toast.makeText(this, "Window $i selected for refresh", Toast.LENGTH_SHORT).show()
            }
            header.addView(windowLabel, LinearLayout.LayoutParams(0, -2, 1f))
            val menu = TextView(this).apply { text = "⋮"; textSize = 23f; setTextColor(cyan); gravity = Gravity.CENTER; setPadding(dp(9), 0, dp(9), 0) }
            header.addView(menu)
            card.addView(header)
            val holder = FrameLayout(this).apply { setBackgroundColor(Color.rgb(6, 16, 31)) }
            holders[i] = holder
            card.addView(holder, LinearLayout.LayoutParams(-1, dp(if (cols == 2) 170 else 230)))
            val open = action("Open window") { openWindow(i) }
            holder.addView(open, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
            menu.setOnClickListener {
                val pop = PopupMenu(this, menu)
                pop.menu.add("Expand window")
                pop.menu.add("Close window")
                pop.setOnMenuItemClickListener { item ->
                    if (item.title == "Expand window") expand(i) else closeWindow(i)
                    true
                }
                pop.show()
            }
            row!!.addView(card, LinearLayout.LayoutParams(0, -2, 1f).apply { setMargins(dp(3), dp(3), dp(3), dp(5)) })
        }
        main.addView(gridScreen, LinearLayout.LayoutParams(-1, 0, 1f))
    }

    // Android WebView does not expose a reliable per-WebView mute API.
    // This button controls the phone's shared media volume, not individual windows.
    private fun toggleDeviceSound() {
        val audio = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        if (!soundOff) {
            savedMediaVolume = audio.getStreamVolume(AudioManager.STREAM_MUSIC)
            audio.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0)
            soundOff = true
        } else {
            if (savedMediaVolume >= 0) audio.setStreamVolume(AudioManager.STREAM_MUSIC, savedMediaVolume, 0)
            soundOff = false
        }
        soundButton.text = if (soundOff) "SOUND ON (DEVICE)" else "SOUND OFF (DEVICE)"
        Toast.makeText(this, "Changes phone media volume for all apps", Toast.LENGTH_SHORT).show()
    }

    /** Repaint only the grid chrome; never recreate or reload live WebViews. */
    private fun refreshGridView() {
        updateAllButton()
        gridContent?.invalidate()
        gridContent?.requestLayout()
        holders.values.forEach { it.invalidate() }
        Toast.makeText(this, "Grid refreshed; open browser pages unchanged", Toast.LENGTH_SHORT).show()
    }

    private fun checkAllWindows() {
        val openCount = browsers.size
        val loadingCount = browsers.values.count { it.progress < 100 }
        val message = "Open: $openCount/$windowCount  •  Loading: $loadingCount  •  Closed: ${windowCount - openCount}"
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    private fun openLinkInSelectedWindow() {
        if (!explicitLink || !validUrl(selectedUrl)) {
            Toast.makeText(this, "Enter a Facebook profile/photo link on Home first", Toast.LENGTH_LONG).show()
            return
        }
        if (!browsers.containsKey(selectedWindow)) {
            openWindow(selectedWindow, useInputLink = true)
        } else {
            browsers[selectedWindow]?.loadUrl(selectedUrl)
        }
        Toast.makeText(this, "Opened link in Window $selectedWindow", Toast.LENGTH_SHORT).show()
    }

    private fun refreshSelectedWindow() {
        val browser = browsers[selectedWindow]
        if (browser == null) {
            Toast.makeText(this, "Open Window $selectedWindow first", Toast.LENGTH_SHORT).show()
        } else {
            browser.reload()
        }
    }

    private fun lastPage(i: Int): String =
        currentPages[i]
            ?: pagePrefs.getString("url_$i", null)?.takeIf { validUrl(it) }
            ?: "https://m.facebook.com/"

    private fun savePage(i: Int, browser: WebView) {
        val url = browser.url.orEmpty()
        if (validUrl(url)) {
            currentPages[i] = url
            pagePrefs.edit().putString("url_$i", url).apply()
        }
    }


    private fun updateAllButton() {
        if (!::allWindowsButton.isInitialized) return
        val allOpen = (1..windowCount).all { browsers.containsKey(it) }
        allWindowsButton.text = if (allOpen) "CLOSE ALL WINDOWS" else "OPEN ALL WINDOWS"
        allWindowsButton.setBackgroundColor(if (allOpen) Color.rgb(150, 36, 57) else Color.rgb(10, 112, 83))
    }

    private fun toggleAllWindows() {
        if ((1..windowCount).all { browsers.containsKey(it) }) {
            for (i in 1..windowCount) closeWindow(i)
        } else {
            // Restore each independent browser's own saved page in the grid.
            for (i in 1..windowCount) if (!browsers.containsKey(i)) openWindow(i, useInputLink = false)
        }
        updateAllButton()
    }

    private fun openWindow(i: Int, useInputLink: Boolean = true) {
        if (browsers.containsKey(i)) return
        if (!WebViewFeature.isFeatureSupported(WebViewFeature.MULTI_PROFILE)) {
            Toast.makeText(this, "Independent WebView profiles not supported", Toast.LENGTH_LONG).show()
            return
        }
        val browser = WebView(this)
        try {
            // Must be assigned before configuring or navigating the WebView.
            WebViewCompat.setProfile(browser, "alam_account_$i")
        } catch (e: Exception) {
            browser.destroy()
            Toast.makeText(this, "Profile setup failed: ${e.message}", Toast.LENGTH_LONG).show()
            return
        }
        // Let the embedded browser consume swipe gestures rather than the outer grid.
        // Returning false keeps native WebView taps, scrolling and text entry working.
        browser.setOnTouchListener { view, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN, MotionEvent.ACTION_MOVE ->
                    view.parent?.requestDisallowInterceptTouchEvent(true)
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL ->
                    view.parent?.requestDisallowInterceptTouchEvent(false)
            }
            false
        }
        browser.isVerticalScrollBarEnabled = true
        browser.isHorizontalScrollBarEnabled = false
        browser.settings.javaScriptEnabled = true
        browser.settings.domStorageEnabled = true
        browser.settings.useWideViewPort = true
        browser.settings.loadWithOverviewMode = true
        browser.settings.builtInZoomControls = true
        browser.settings.displayZoomControls = false
        browser.settings.textZoom = 100
        browser.settings.layoutAlgorithm = WebSettings.LayoutAlgorithm.NORMAL
        browser.overScrollMode = View.OVER_SCROLL_NEVER
        browser.settings.mediaPlaybackRequiresUserGesture = true
        browser.isFocusable = true
        browser.isFocusableInTouchMode = true
        browser.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView, url: String) {
                if (validUrl(url)) {
                    currentPages[i] = url
                    pagePrefs.edit().putString("url_$i", url).apply()
                }
            }
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                return request.url.scheme != "https" && request.url.scheme != "http"
            }
        }
        browsers[i] = browser
        val holder = holders[i] ?: return
        holder.removeAllViews()
        attachCompactBrowser(i, browser)
        browser.loadUrl(if (useInputLink && explicitLink && validUrl(selectedUrl)) selectedUrl else lastPage(i))
        updateAllButton()
    }
    /**
     * Render a normal phone-width viewport, then scale the entire WebView into
     * its small card. Android's view transform also maps touch coordinates,
     * so links, taps and scrolling remain usable in compact mode.
     * No page CSS, JavaScript or Facebook playback behavior is modified.
     */
    private fun detachCompactListener(i: Int) {
        val holder = holders[i] ?: return
        compactListeners.remove(i)?.let { holder.removeOnLayoutChangeListener(it) }
    }

    /** Keep the same WebView instance and its independent profile when resizing.
     * Avoid accumulating layout callbacks across expand/back cycles.
     */
    private fun attachCompactBrowser(i: Int, browser: WebView) {
        val holder = holders[i] ?: return
        detachCompactListener(i)
        (browser.parent as? ViewGroup)?.removeView(browser)
        holder.removeAllViews()
        holder.clipChildren = true
        holder.clipToPadding = true
        browser.pivotX = 0f
        browser.pivotY = 0f
        val virtualWidth = dp(virtualWidthDp)
        holder.addView(browser, FrameLayout.LayoutParams(virtualWidth, dp(340)))
        val listener = View.OnLayoutChangeListener { _, _, _, _, _, _, _, _, _ ->
            if (browser.parent !== holder || holder.width <= 0 || holder.height <= 0) return@OnLayoutChangeListener
            val factor = (holder.width.toFloat() / virtualWidth).coerceIn(0.1f, 1f)
            val height = (holder.height / factor).toInt().coerceAtLeast(1)
            val lp = browser.layoutParams as FrameLayout.LayoutParams
            if (lp.width != virtualWidth || lp.height != height) {
                lp.width = virtualWidth
                lp.height = height
                browser.layoutParams = lp
            }
            if (browser.scaleX != factor || browser.scaleY != factor) {
                browser.scaleX = factor
                browser.scaleY = factor
            }
        }
        compactListeners[i] = listener
        holder.addOnLayoutChangeListener(listener)
        holder.post { if (browser.parent === holder) {
            val factor = (holder.width.toFloat() / virtualWidth).coerceIn(0.1f, 1f)
            val lp = browser.layoutParams as FrameLayout.LayoutParams
            lp.height = (holder.height / factor).toInt().coerceAtLeast(1)
            browser.layoutParams = lp
            browser.scaleX = factor
            browser.scaleY = factor
        } }
    }

    private fun closeWindow(i: Int) {
        if (expanded == i) restoreGrid()
        detachCompactListener(i)
        browsers.remove(i)?.let { web -> savePage(i, web); (web.parent as? ViewGroup)?.removeView(web); web.destroy() }
        holders[i]?.apply {
            removeAllViews()
            addView(action("Open window") { openWindow(i) }, FrameLayout.LayoutParams(-1, -2, Gravity.CENTER))
        }
        updateAllButton()
    }
    private fun expand(i: Int) {
        if (!browsers.containsKey(i)) openWindow(i, useInputLink = false)
        val browser = browsers[i] ?: return
        detachCompactListener(i)
        (browser.parent as? ViewGroup)?.removeView(browser)
        gridScreen.visibility = View.GONE
        expanded = i
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        activePanel = panel
        panel.addView(action("← Back to small windows") { restoreGrid() }, LinearLayout.LayoutParams(-1, dp(52)))
        browser.scaleX = 1f
        browser.scaleY = 1f
        panel.addView(browser, LinearLayout.LayoutParams(-1, 0, 1f))
        main.addView(panel, LinearLayout.LayoutParams(-1, 0, 1f))
    }
    private fun restoreGrid() {
        val i = expanded ?: return
        val browser = browsers[i]
        if (browser != null) {
            (browser.parent as? ViewGroup)?.removeView(browser)
            attachCompactBrowser(i, browser)
            // Do not force an old pixel scroll offset after resizing: the site
            // may have reflowed and restoring it can jump to the wrong content.
        }
        activePanel?.let { main.removeView(it) }
        activePanel = null
        expanded = null
        gridScreen.visibility = View.VISIBLE
    }
    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (expanded != null) restoreGrid() else super.onBackPressed()
    }
    override fun onDestroy() {
        compactListeners.keys.toList().forEach { detachCompactListener(it) }
        browsers.forEach { (i, web) -> savePage(i, web); (web.parent as? ViewGroup)?.removeView(web); web.destroy() }
        browsers.clear()
        // Restore the original media volume when leaving the grid.
        if (soundOff && savedMediaVolume >= 0) {
            (getSystemService(Context.AUDIO_SERVICE) as AudioManager).setStreamVolume(AudioManager.STREAM_MUSIC, savedMediaVolume, 0)
        }
        super.onDestroy()
    }
}
