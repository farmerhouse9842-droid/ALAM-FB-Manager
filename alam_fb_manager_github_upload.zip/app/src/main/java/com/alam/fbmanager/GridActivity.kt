package com.alam.fbmanager

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.widget.*

/** Automatically opens the grid screen when a valid video URL is pasted.
 * Each card is a navigation shortcut; it does not play or load videos in bulk. */
class GridActivity : Activity() {
 private val blue=Color.rgb(27,211,255)
 private fun panel(): GradientDrawable = GradientDrawable().apply {
  setColor(Color.rgb(13,30,59)); cornerRadius=24f; setStroke(2,Color.rgb(20,116,188))
 }
 override fun onCreate(savedInstanceState:Bundle?) {
  super.onCreate(savedInstanceState)
  window.statusBarColor=Color.rgb(4,10,25)
  window.navigationBarColor=Color.rgb(4,10,25)
  val url=intent.getStringExtra("video_url").orEmpty()
  val count=intent.getIntExtra("account_count",10).coerceIn(1,20)
  val grid=intent.getBooleanExtra("grid_mode",true)
  val scroll=ScrollView(this).apply { setBackgroundColor(Color.rgb(4,10,25)) }
  val root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(18,24,18,30) }
  scroll.addView(root)
  fun label(value:String, size:Float=16f):TextView=TextView(this).apply {
   text=value; textSize=size; setTextColor(Color.WHITE);setPadding(14,16,14,16)
  }
  root.addView(label("ALAM FB MANAGER  •  GRID",21f).apply {setTextColor(blue);typeface=Typeface.DEFAULT_BOLD})
  root.addView(label("Selected video: $url",12f).apply {background=panel()})
  root.addView(label("$count account shortcuts • Tap a card to open the link in that session",13f).apply {setTextColor(blue)})
  val cols=if(grid) 2 else 1
  var row:LinearLayout?=null
  for (i in 1..count) {
   if ((i-1)%cols==0) {
    row=LinearLayout(this).apply {orientation=LinearLayout.HORIZONTAL}
    root.addView(row,LinearLayout.LayoutParams(-1,-2).apply {bottomMargin=12})
   }
   val card=LinearLayout(this).apply {orientation=LinearLayout.VERTICAL;gravity=Gravity.CENTER;background=panel();setPadding(8,14,8,14)}
   card.addView(label("Account $i",16f).apply {gravity=Gravity.CENTER;typeface=Typeface.DEFAULT_BOLD})
   card.addView(label("Tap to open video",12f).apply {gravity=Gravity.CENTER;setTextColor(blue)})
   card.setOnClickListener {
    try {
     val slot=Class.forName("com.alam.fbmanager.Slot$i")
     startActivity(Intent(this,slot).putExtra("video_url",url))
    } catch (e:Exception) { Toast.makeText(this,"Cannot open account $i",Toast.LENGTH_SHORT).show() }
   }
   row!!.addView(card,LinearLayout.LayoutParams(0,140,1f).apply {marginEnd=8})
  }
  setContentView(scroll)
 }
}
