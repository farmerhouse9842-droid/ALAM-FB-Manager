package com.alam.fbmanager
class Slot6 : AccountActivity()
